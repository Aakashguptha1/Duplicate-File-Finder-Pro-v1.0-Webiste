Welcome to Duplicate File Finder Pro v1.0 - Win 7

Installation Guide:

	1.Install VC_redist.x64 (for 64-bit systems) or VC_redist.x86 (for 32-bit systems), 	depending on your system requirements.

	2.Install Python 3.8.10 (python-3.8.10-amd64) on your system.

After installation, open Duplicate File Finder Pro v1.0 - Win 7.exe.

If you encounter any errors, please contact Protocol_Protectors@proton.me for support.